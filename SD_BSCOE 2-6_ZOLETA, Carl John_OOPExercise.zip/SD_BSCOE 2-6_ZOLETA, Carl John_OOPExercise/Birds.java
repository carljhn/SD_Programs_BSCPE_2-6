public abstract class Birds extends Zoo {
    public Birds(String name, int age, String gender) {
        super(name, age, gender);
    }
}