public abstract class Mammals extends Zoo {
    public Mammals(String name, int age, String gender) {
        super(name, age, gender);
    }
}
