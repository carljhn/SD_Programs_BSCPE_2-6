public abstract class Reptiles extends Zoo {
    public Reptiles(String name, int age, String gender) {
        super(name, age, gender);
    }
}